# Plate Log

Photo calorie tracker with weekly body check-ins. Runs entirely in your phone's browser.

- Data (meals, weights, check-in photos) is stored on the phone in IndexedDB. Use Setup → Save backup now and then.
- Photo estimates call the Anthropic API directly with your own key, which is stored only on the phone.

Hosting: GitHub Pages from the repo root (Settings → Pages → Deploy from branch → main / root).
